package com.sales.ejb;

import java.io.IOException;
import java.util.List;

import com.sales.model.Book;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/bookServlet")
public class BooksServlet extends HttpServlet{

    @EJB
    private CartBean cartBean;

    protected void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Book> books = cartBean.getSavedBooks();
        request.setAttribute("books", books);
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
    
    protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        double price = Double.parseDouble(request.getParameter("price"));

        Book book = new Book(title, author, price);
        cartBean.addBook(book);
        response.sendRedirect("/bookServlet");
    }
}
